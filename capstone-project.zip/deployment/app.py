import streamlit as st

st.title("Customer Churn Prediction")

st.write("This is a basic deployment demo for the capstone project.")

st.success("Project Completed Successfully!")