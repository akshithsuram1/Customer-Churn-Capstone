

## Customer Churn Prediction using Machine Learning

## Project Overview

This project predicts whether a customer will churn (leave the company) using a Machine Learning model. Customer churn prediction helps businesses identify customers who are likely to leave and take actions to improve customer retention.


## Objective

Analyze customer churn data.

Preprocess and clean the dataset.

Train a Machine Learning model.

Predict customer churn.

Evaluate the model performance.

Provide business recommendations.


## Dataset Information

Dataset Name: Customer Churn

Total Records: 500

Total Columns: 9

Missing Values: None


Columns

CustomerID

Tenure

MonthlyCharges

TotalCharges

Contract

PaymentMethod

PaperlessBilling

SeniorCitizen

Churn (Target Variable)


## Technologies Used

Python

Google Colab

Pandas

NumPy

Matplotlib

Scikit-learn


## Machine Learning Model

Random Forest Classifier


Steps Performed

1. Imported required libraries.


2. Loaded the dataset.


3. Checked dataset information.


4. Checked for missing values.


5. Encoded categorical columns using LabelEncoder.


6. Split the dataset into training and testing data.


7. Trained a Random Forest Classifier.


8. Predicted customer churn.


9. Evaluated the model using Accuracy, Classification Report, and Confusion Matrix.


10. Created data visualization graphs.






## Results

The model successfully predicted customer churn.

The confusion matrix showed good prediction performance.

Tenure was the most important feature for predicting customer churn.

Monthly Charges and Total Charges also influenced the prediction.




## Business Recommendations

Reward loyal customers.

Encourage long-term contracts.

Improve customer support.

Offer discounts to customers with higher monthly charges.

Monitor customers who are likely to churn.





## Conclusion

This project demonstrates a complete Machine Learning workflow, including data preprocessing, model training, evaluation, visualization, and business recommendations. The developed model can help businesses identify customers at risk of leaving and improve customer retention strategies.